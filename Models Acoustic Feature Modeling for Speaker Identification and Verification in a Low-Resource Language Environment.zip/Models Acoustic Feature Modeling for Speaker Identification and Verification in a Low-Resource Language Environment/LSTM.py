import os
import numpy as np
import librosa
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
from tqdm import tqdm
import tensorflow as tf

# --- 1. CONFIGURATION PATHS ---
TRAIN_VAL_DIR = r'/content/extracted_train_val/DataSet/CodeModel/Dataset_complet_for_fitering 2'
TEST_DIR = r'/content/extracted_test/VoicesForTest'

# --- 2. UPDATED MODEL SETTINGS FOR 1-SECOND AUDIO ---
SAMPLE_RATE = 22050
N_MFCC = 20
MAX_TIME_STEPS = 44  # <-- CHANGED: 1 second of audio = ~44 time frames
EPOCHS = 50
BATCH_SIZE = 32

# --- 3. LSTM FEATURE EXTRACTION FUNCTION ---
def extract_lstm_features(file_path):
    """Extracts MFCCs and keeps the TIME dimension intact for the LSTM."""
    try:
        # <-- CHANGED: duration is now exactly 1.0 seconds
        audio, sr = librosa.load(file_path, sr=SAMPLE_RATE, duration=1.0)
        
        # If the file is completely empty or corrupted, skip it
        if len(audio) < 512: 
            return None
            
        mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
        
        # Pad with zeros ONLY if the 1-second audio is slightly too short, 
        # or cut it if it is slightly too long.
        pad_width = MAX_TIME_STEPS - mfcc.shape[1]
        if pad_width > 0:
            mfcc = np.pad(mfcc, pad_width=((0, 0), (0, pad_width)), mode='constant')
        else:
            mfcc = mfcc[:, :MAX_TIME_STEPS]
            
        # Transpose so shape is (Time_Steps, Features) -> (44, 20)
        return mfcc.T 
    except Exception:
        return None

# --- 4. SMART DATA COLLECTION ---
def load_data_from_directory(directory):
    dataset = []
    print(f"🔍 Scanning directory: {directory}")
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.wav', '.mp3', '.ogg')):
                dataset.append({
                    'speaker': os.path.basename(root),
                    'path': os.path.join(root, file)
                })
    return dataset

def prepare_xy(dataset):
    X, y = [], []
    for item in tqdm(dataset, desc="Processing Audio for LSTM"):
        features = extract_lstm_features(item['path'])
        if features is not None:
            X.append(features)
            y.append(item['speaker'])
    return np.array(X), np.array(y)

print("\n--- Loading Data ---")
train_val_raw = load_data_from_directory(TRAIN_VAL_DIR)
test_raw = load_data_from_directory(TEST_DIR)

print("\n--- Extracting 1-Second Sequence Features for Training & Validation ---")
X_train_val, y_train_val = prepare_xy(train_val_raw)

print("\n--- Extracting 1-Second Sequence Features for Testing ---")
X_test, y_test = prepare_xy(test_raw)

# Encode Speaker Names
label_encoder = LabelEncoder()
label_encoder.fit(np.concatenate((y_train_val, y_test))) 

y_train_val_encoded = label_encoder.transform(y_train_val)
y_test_encoded = label_encoder.transform(y_test)
num_classes = len(label_encoder.classes_)

# Split Training and Validation
X_train, X_val, y_train, y_val = train_test_split(
    X_train_val, y_train_val_encoded, test_size=0.15, random_state=42
)

print(f"\n📊 Data Split Summary:")
print(f"NEW Data Shape: {X_train.shape} --> (Files, 44 Time Steps, 20 MFCCs)")
print(f"Total Classes (Speakers): {num_classes}")

# --- 5. THE CUSTOM CALLBACK (For the Red Test Line) ---
class TestPerformanceCallback(tf.keras.callbacks.Callback):
    def __init__(self, test_data, test_labels):
        super().__init__()
        self.test_data = test_data
        self.test_labels = test_labels
        self.test_accuracies = [] 

    def on_epoch_end(self, epoch, logs=None):
        loss, acc = self.model.evaluate(self.test_data, self.test_labels, verbose=0)
        self.test_accuracies.append(acc)
        print(f" — Custom Test Accuracy: {acc:.4f}")

test_inspector = TestPerformanceCallback(X_test, y_test_encoded)

# --- 6. BUILD THE LSTM NEURAL NETWORK ---
print("\n--- Compiling LSTM Model ---")
model = tf.keras.Sequential([
    tf.keras.layers.LSTM(128, return_sequences=True, input_shape=(MAX_TIME_STEPS, N_MFCC)),
    tf.keras.layers.Dropout(0.3),
    
    tf.keras.layers.LSTM(64),
    tf.keras.layers.Dropout(0.3),
    
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(num_classes, activation='softmax')
])

model.compile(optimizer='adam', 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy'])

# --- 7. TRAIN THE LSTM ---
print("\n--- Starting LSTM Training ---")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    callbacks=[test_inspector]
)

# --- 8. PLOT THE CHART (3 LINES) ---
print("\nGenerating Learning Curve...")
plt.figure(figsize=(10, 6))

iterations_range = range(1, EPOCHS + 1)
plt.plot(iterations_range, history.history['accuracy'], marker='s', color='blue', label='train')
plt.plot(iterations_range, history.history['val_accuracy'], marker='*', color='lawngreen', label='validation')
plt.plot(iterations_range, test_inspector.test_accuracies, marker='*', color='red', markerfacecolor='white', label='test')

plt.title('Optimized 1-Sec LSTM Iterative Performance')
plt.xlabel('Epochs (Iterations)')
plt.ylabel('Accuracy')
plt.legend(loc='lower right')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# --- 9. FINAL METRICS & REPORT ---
print("\n" + "="*50)
print("     FINAL TEST DATASET EVALUATION REPORT")
print("="*50)

y_pred_probs = model.predict(X_test)
y_pred_encoded = np.argmax(y_pred_probs, axis=1)

y_test_names = label_encoder.inverse_transform(y_test_encoded)
y_pred_names = label_encoder.inverse_transform(y_pred_encoded)

final_acc = accuracy_score(y_test_names, y_pred_names)
precision = precision_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
recall = recall_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
f1 = f1_score(y_test_names, y_pred_names, average='weighted', zero_division=0)

print(f"⭐ Final Accuracy : {final_acc * 100:.2f}%")
print(f"🎯 Precision      : {precision * 100:.2f}%")
print(f"🔍 Recall         : {recall * 100:.2f}%")
print(f"⚖️ F1-Score       : {f1 * 100:.2f}%")
print("-" * 50)

report = classification_report(y_test_names, y_pred_names, digits=4)
print("Detailed Summary (Weighted Average):")
lines = report.split('\n')
print(lines[0])
print(lines[-2]) 
print("="*50)