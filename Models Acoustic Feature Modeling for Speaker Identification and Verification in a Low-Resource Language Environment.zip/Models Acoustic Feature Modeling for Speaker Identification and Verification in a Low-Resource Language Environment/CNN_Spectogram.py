import os
import librosa
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

# ---------- 1. CONFIGURATION & TWO PATHS ----------
# 🔴 Change these to your exact extracted folder paths!
TRAIN_VAL_DIR = r'/content/extracted_train_val/DataSet/CodeModel/Dataset_complet_for_fitering 2'
TEST_DIR = r'/content/extracted_test/VoicesForTest'

SAMPLE_RATE = 22050
DURATION = 1.0
N_MELS = 64
MAX_PAD_LEN = 44  # 1 second of audio at 22050Hz/512 hop = ~44 frames
EPOCHS = 50
BATCH_SIZE = 32

# ---------- GPU CHECK ----------
print("GPU Status:", tf.config.list_physical_devices('GPU'))

# ---------- 2. FEATURE EXTRACTION (MEL-SPECTROGRAM) ----------
def create_spectrogram(path):
    """Converts 1-second audio into a high-res 2D Mel-Spectrogram Image"""
    try:
        audio, sr = librosa.load(path, sr=SAMPLE_RATE, duration=DURATION)
        if len(audio) < 2048:
            return None

        # Create the Mel-Spectrogram (Shape: 64 Mels x 44 Time Steps)
        mel = librosa.feature.melspectrogram(y=audio, sr=sr, n_mels=N_MELS)

        # Convert power to Decibels (dB) for better neural network processing
        mel_db = librosa.power_to_db(mel, ref=np.max)

        # Pad or Truncate strictly to exactly 44 frames
        if mel_db.shape[1] > MAX_PAD_LEN:
            mel_db = mel_db[:, :MAX_PAD_LEN]
        else:
            pad_width = MAX_PAD_LEN - mel_db.shape[1]
            mel_db = np.pad(mel_db, ((0, 0), (0, pad_width)), mode='constant')

        return mel_db.astype(np.float32)
    except Exception:
        return None

# ---------- 3. SMART DATA COLLECTION ----------
def load_and_extract(directory, desc_name):
    X_list, y_list = [], []
    print(f"\n🔍 Scanning {desc_name} directory: {directory}")

    # First gather all file paths so tqdm can show a progress bar
    file_data = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.wav', '.mp3', '.ogg')):
                file_data.append({'speaker': os.path.basename(root), 'path': os.path.join(root, file)})

    for item in tqdm(file_data, desc=f"Extracting {desc_name} Mel-Specs"):
        spec = create_spectrogram(item['path'])
        if spec is not None:
            X_list.append(spec)
            y_list.append(item['speaker'])

    return np.array(X_list), np.array(y_list)

# Load Path 1 (Train & Validation) and Path 2 (Unseen Test)
X_train_val_raw, y_train_val_raw = load_and_extract(TRAIN_VAL_DIR, "Train/Val")
X_test_raw, y_test_raw = load_and_extract(TEST_DIR, "Test")

# ---------- 4. LABEL ENCODING & SPLITTING ----------
# Fit encoder on ALL speakers to ensure the numbers match perfectly
le = LabelEncoder()
le.fit(np.concatenate((y_train_val_raw, y_test_raw)))

y_train_val_enc = le.transform(y_train_val_raw)
y_test_enc = le.transform(y_test_raw)
num_classes = len(le.classes_)

# Split Path 1 into 85% Train / 15% Val
X_train, X_val, y_train, y_val = train_test_split(
    X_train_val_raw, y_train_val_enc, test_size=0.15, stratify=y_train_val_enc, random_state=42
)

# ---------- 5. GLOBAL NORMALIZATION (CRITICAL FOR MEL-SPECS) ----------
print("\n⚙️ Applying Global Normalization...")
mean = np.mean(X_train)
std = np.std(X_train) + 1e-8

X_train = (X_train - mean) / std
X_val = (X_val - mean) / std
X_test = (X_test_raw - mean) / std

# Add the "Color Channel" for the CNN -> Shape becomes (Files, 64, 44, 1)
X_train = X_train[..., np.newaxis]
X_val = X_val[..., np.newaxis]
X_test = X_test[..., np.newaxis]

print(f"\n📊 DATA READY:")
print(f"Total Speakers (Classes): {num_classes}")
print(f"Training Files:   {len(X_train)}")
print(f"Validation Files: {len(X_val)}")
print(f"Test Files:       {len(X_test)}")
print(f"Input Shape:      {X_train.shape[1:]}")

# ---------- 6. CUSTOM TEST CALLBACK ----------
class TestPerformanceCallback(tf.keras.callbacks.Callback):
    def __init__(self, test_data, test_labels):
        super().__init__()
        self.test_data = test_data
        self.test_labels = test_labels
        self.test_accuracies = []
        self.test_losses = []

    def on_epoch_end(self, epoch, logs=None):
        loss, acc = self.model.evaluate(self.test_data, self.test_labels, verbose=0)
        self.test_accuracies.append(acc)
        self.test_losses.append(loss)
        print(f" — Custom Test Acc: {acc:.4f} | Test Loss: {loss:.4f}")

test_inspector = TestPerformanceCallback(X_test, y_test_enc)

# Callbacks to adjust learning rate and stop if fully trained
lr_scheduler = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_accuracy', factor=0.5, patience=3, min_lr=1e-5, verbose=1)
early_stopper = tf.keras.callbacks.EarlyStopping(monitor='val_accuracy', patience=8, restore_best_weights=True, verbose=1)

# ---------- 7. BUILD THE STRONG MEL-CNN ----------
print("\n--- Compiling Mel-CNN Model ---")
model = tf.keras.Sequential([
    # BLOCK 1
    tf.keras.layers.Conv2D(32, (3,3), activation='relu', padding='same', input_shape=X_train.shape[1:]),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Conv2D(32, (3,3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.MaxPooling2D((2,2)),
    tf.keras.layers.Dropout(0.2),

    # BLOCK 2
    tf.keras.layers.Conv2D(64, (3,3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.MaxPooling2D((2,2)),
    tf.keras.layers.Dropout(0.3),

    # BLOCK 3
    tf.keras.layers.Conv2D(128, (3,3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.MaxPooling2D((2,2)),
    tf.keras.layers.Dropout(0.3),

    # BLOCK 4
    tf.keras.layers.Conv2D(256, (3,3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.MaxPooling2D((2,2)),
    tf.keras.layers.Dropout(0.4),

    # CLASSIFICATION HEAD
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(512, activation='relu'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(num_classes, activation='softmax')
])

model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])
model.summary()

# ---------- 8. TRAIN ----------
print("\n--- Starting Model Training ---")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    callbacks=[test_inspector, lr_scheduler, early_stopper]
)

# ---------- 9. PLOT THE PROFESSIONAL DUAL-CHART ----------
actual_epochs = len(history.history['accuracy'])
epochs_range = range(1, actual_epochs + 1)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# Plot 1: Accuracy
ax1.plot(epochs_range, history.history['accuracy'], '--', color='red', label='Train Accuracy')
ax1.plot(epochs_range, history.history['val_accuracy'], '-', color='blue', label='Validation Accuracy')
ax1.plot(epochs_range, test_inspector.test_accuracies, ':', color='green', linewidth=2.5, label='Test Accuracy')
ax1.set_title('Mel-CNN Accuracy Curve')
ax1.set_xlabel('Epoch')
ax1.set_ylabel('Accuracy')
ax1.legend(loc='lower right')
ax1.grid(True, linestyle='--', alpha=0.6)

# Plot 2: Loss
ax2.plot(epochs_range, history.history['loss'], '--', color='red', label='Train Loss')
ax2.plot(epochs_range, history.history['val_loss'], '-', color='blue', label='Validation Loss')
ax2.plot(epochs_range, test_inspector.test_losses, ':', color='green', linewidth=2.5, label='Test Loss')
ax2.set_title('Mel-CNN Loss Curve')
ax2.set_xlabel('Epoch')
ax2.set_ylabel('Loss')
ax2.legend(loc='upper right')
ax2.grid(True, linestyle='--', alpha=0.6)

plt.tight_layout()
plt.show()

# ---------- 10. FINAL REPORT ----------
print("\n" + "="*50)
print("     FINAL TEST DATASET EVALUATION REPORT")
print("="*50)

y_pred_probs = model.predict(X_test)
y_pred_encoded = np.argmax(y_pred_probs, axis=1)

y_test_names = le.inverse_transform(y_test_enc)
y_pred_names = le.inverse_transform(y_pred_encoded)

final_acc = accuracy_score(y_test_names, y_pred_names)
precision = precision_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
recall = recall_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
f1 = f1_score(y_test_names, y_pred_names, average='weighted', zero_division=0)

print(f"⭐ Final Test Accuracy : {final_acc * 100:.2f}%")
print(f"🎯 Precision           : {precision * 100:.2f}%")
print(f"🔍 Recall              : {recall * 100:.2f}%")
print(f"⚖️ F1-Score            : {f1 * 100:.2f}%")
print("-" * 50)

report = classification_report(y_test_names, y_pred_names, digits=4)
print("Detailed Summary (Weighted Average):")
lines = report.split('\n')
print(lines[0])
print(lines[-2])
print("="*50)