import os
import zipfile
import numpy as np
import librosa
import warnings
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.exceptions import ConvergenceWarning
from tqdm import tqdm

# Suppress convergence warnings since we are doing custom step-by-step training
warnings.filterwarnings("ignore", category=ConvergenceWarning)

# --- 1. CONFIGURATION PATHS ---
TRAIN_VAL_ZIP = r'/content/DataSetTrain&Vali.zip'
TEST_ZIP = r'/content/VoicesForTest.zip'

TRAIN_VAL_BASE_DIR = r'/content/extracted_train_val'
TEST_BASE_DIR = r'/content/extracted_test'

# --- 2. AUTOMATIC UNZIPPER & FOLDER FINDER ---
def extract_and_find_data(zip_path, extract_dir):
    """Extracts a zip file and intelligently finds the actual audio folder."""
    if not os.path.exists(zip_path):
        raise FileNotFoundError(f"❌ ERROR: Cannot find '{zip_path}'. Please upload it to Colab!")
        
    os.makedirs(extract_dir, exist_ok=True)
    print(f"📦 Extracting {zip_path}...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
        
    # Dig past useless nested folders
    current_dir = extract_dir
    while True:
        contents = [f for f in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, f))]
        if len(contents) == 1:
            current_dir = os.path.join(current_dir, contents[0])
        else:
            break
    return current_dir

# Extract and set the actual directories
TRAIN_VAL_DIR = extract_and_find_data(TRAIN_VAL_ZIP, TRAIN_VAL_BASE_DIR)
TEST_DIR = extract_and_find_data(TEST_ZIP, TEST_BASE_DIR)

# --- 3. MODEL SETTINGS ---
SAMPLE_RATE = 22050
N_MFCC = 20
N_COMPONENTS = 8  # Fixed to 8 to prevent math crashes with short audio
ITERATIONS = 20   # Number of steps for the learning curve chart

# --- 4. FEATURE EXTRACTION FUNCTION ---
def extract_mfcc_frames(file_path):
    """Extracts MFCC features. Returns shape (n_frames, n_mfcc)"""
    try:
        audio, sr = librosa.load(file_path, sr=SAMPLE_RATE, duration=1.0)
        if len(audio) < 2048: 
            return None
        mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
        return mfcc.T 
    except Exception:
        return None

# --- 5. SMART DATA COLLECTION ---
def load_data_from_directory(directory):
    dataset = []
    print(f"🔍 Scanning directory: {directory}")
    # Using os.walk to find hidden audio files automatically
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.wav', '.mp3', '.ogg')):
                speaker_name = os.path.basename(root)
                dataset.append({
                    'speaker': speaker_name,
                    'path': os.path.join(root, file)
                })
    return dataset

print("\n--- Loading Data ---")
train_val_data = load_data_from_directory(TRAIN_VAL_DIR)
if not train_val_data:
    raise ValueError("❌ ERROR: No audio files found in training data.")

train_data, val_data = train_test_split(train_val_data, test_size=0.15, random_state=42)
test_data = load_data_from_directory(TEST_DIR)

print(f"\n📊 Data Split Summary:")
print(f"Training Files:   {len(train_data)}")
print(f"Validation Files: {len(val_data)}")
print(f"Testing Files:    {len(test_data)}")

# --- 6. PREPARE TRAINING FEATURES ---
print("\n--- Extracting Training Features ---")
train_features_by_speaker = {}
speakers = list(set([item['speaker'] for item in train_data]))

for spk in speakers:
    train_features_by_speaker[spk] = []

for item in tqdm(train_data, desc="Extracting Train MFCCs"):
    frames = extract_mfcc_frames(item['path'])
    if frames is not None:
        train_features_by_speaker[item['speaker']].append(frames)

for spk in speakers:
    if len(train_features_by_speaker[spk]) > 0:
        train_features_by_speaker[spk] = np.vstack(train_features_by_speaker[spk])

# --- 7. INITIALIZE GMMs (WITH MATH FIXES) ---
# Added reg_covar=1e-3 to stop the LinAlgError (Positive Definite error)
gmms = {spk: GaussianMixture(n_components=N_COMPONENTS, max_iter=1, warm_start=True, random_state=42, reg_covar=1e-3) 
        for spk in speakers}

def evaluate_gmms(dataset, gmm_dict):
    y_true, y_pred = [], []
    for item in dataset:
        frames = extract_mfcc_frames(item['path'])
        if frames is not None:
            best_score = -np.inf
            best_spk = None
            for spk, gmm in gmm_dict.items():
                try:
                    score = gmm.score(frames)
                    if score > best_score:
                        best_score = score
                        best_spk = spk
                except: pass
                
            y_true.append(item['speaker'])
            y_pred.append(best_spk)
    return y_true, y_pred, accuracy_score(y_true, y_pred)

# --- 8. ITERATIVE TRAINING LOOP ---
print("\n--- Starting Iterative GMM Training ---")
history = {'train': [], 'val': [], 'test': []}

for iteration in range(1, ITERATIONS + 1):
    for spk in speakers:
        if spk in train_features_by_speaker and len(train_features_by_speaker[spk]) > 0:
            gmms[spk].fit(train_features_by_speaker[spk])
            
    # Test on a small subset (200 files) during the loop so it doesn't freeze your CPU
    _, _, train_acc = evaluate_gmms(train_data[:200], gmms) 
    _, _, val_acc = evaluate_gmms(val_data[:200], gmms)
    _, _, test_acc = evaluate_gmms(test_data[:200], gmms)
    
    history['train'].append(train_acc)
    history['val'].append(val_acc)
    history['test'].append(test_acc)
    
    print(f"Iteration {iteration}/{ITERATIONS} | Train Acc: {train_acc:.2f} | Val Acc: {val_acc:.2f} | Test Acc: {test_acc:.2f}")

# --- 9. PLOT THE CHART ---
print("\nGenerating Learning Curve...")
plt.figure(figsize=(10, 6))
iterations_range = range(1, ITERATIONS + 1)
plt.plot(iterations_range, history['train'], marker='s', color='blue', label='train')
plt.plot(iterations_range, history['val'], marker='*', color='lawngreen', label='validation')
plt.plot(iterations_range, history['test'], marker='*', color='red', markerfacecolor='white', label='test')

plt.title('GMM Iterative Performance')
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.legend(loc='lower right')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# --- 10. FINAL METRICS & REPORT ---
print("\n" + "="*50)
print("     FINAL TEST DATASET EVALUATION REPORT")
print("="*50)

# Full evaluation on Unseen Test Path
y_true_final, y_pred_final, final_acc = evaluate_gmms(test_data, gmms)

precision = precision_score(y_true_final, y_pred_final, average='weighted', zero_division=0)
recall = recall_score(y_true_final, y_pred_final, average='weighted', zero_division=0)
f1 = f1_score(y_true_final, y_pred_final, average='weighted', zero_division=0)

print(f"⭐ Final Accuracy : {final_acc * 100:.2f}%")
print(f"🎯 Precision      : {precision * 100:.2f}%")
print(f"🔍 Recall         : {recall * 100:.2f}%")
print(f"⚖️ F1-Score       : {f1 * 100:.2f}%")
print("-" * 50)

report = classification_report(y_true_final, y_pred_final, digits=4)
print("Detailed Summary (Weighted Average):")
lines = report.split('\n')
print(lines[0])
print(lines[-2]) 
print("="*50)