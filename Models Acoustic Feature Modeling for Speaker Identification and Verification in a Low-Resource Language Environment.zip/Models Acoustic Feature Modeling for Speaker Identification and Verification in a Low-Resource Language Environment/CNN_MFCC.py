import os
import numpy as np
import librosa
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
from tqdm import tqdm
import tensorflow as tf

# --- 1. CONFIGURATION PATHS ---
TRAIN_VAL_DIR = r'/content/extracted_train_val/DataSet/CodeModel/Dataset_complet_for_fitering 2'
TEST_DIR = r'/content/extracted_test/VoicesForTest'

# --- 2. SETTINGS ---
SAMPLE_RATE = 22050
N_MFCC = 20
MAX_TIME_STEPS = 44  # 1 second of audio
EPOCHS = 50
BATCH_SIZE = 32

# --- 3. CNN FEATURE EXTRACTION ---
def extract_cnn_features(file_path):
    try:
        audio, sr = librosa.load(file_path, sr=SAMPLE_RATE, duration=1.0)
        if len(audio) < 512: 
            return None
            
        mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
        
        pad_width = MAX_TIME_STEPS - mfcc.shape[1]
        if pad_width > 0:
            mfcc = np.pad(mfcc, pad_width=((0, 0), (0, pad_width)), mode='constant')
        else:
            mfcc = mfcc[:, :MAX_TIME_STEPS]
            
        return mfcc.T  
    except Exception:
        return None

# --- 4. DATA COLLECTION ---
def load_data_from_directory(directory):
    dataset = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.wav', '.mp3', '.ogg')):
                dataset.append({
                    'speaker': os.path.basename(root),
                    'path': os.path.join(root, file)
                })
    return dataset

def prepare_xy(dataset):
    X, y = [], []
    for item in tqdm(dataset, desc="Processing Audio for Super CNN"):
        features = extract_cnn_features(item['path'])
        if features is not None:
            X.append(features)
            y.append(item['speaker'])
            
    X = np.expand_dims(np.array(X), axis=-1) 
    return X, np.array(y)

print("\n--- Loading Data ---")
train_val_raw = load_data_from_directory(TRAIN_VAL_DIR)
test_raw = load_data_from_directory(TEST_DIR)

print("\n--- Extracting Features ---")
X_train_val, y_train_val = prepare_xy(train_val_raw)
X_test, y_test = prepare_xy(test_raw)

# Encode Labels
label_encoder = LabelEncoder()
label_encoder.fit(np.concatenate((y_train_val, y_test))) 

y_train_val_encoded = label_encoder.transform(y_train_val)
y_test_encoded = label_encoder.transform(y_test)
num_classes = len(label_encoder.classes_)

X_train, X_val, y_train, y_val = train_test_split(
    X_train_val, y_train_val_encoded, test_size=0.15, random_state=42
)

# --- 5. CALLBACKS (The AI Intelligence) ---
class TestPerformanceCallback(tf.keras.callbacks.Callback):
    def __init__(self, test_data, test_labels):
        super().__init__()
        self.test_data = test_data
        self.test_labels = test_labels
        self.test_accuracies = [] 
        self.test_losses = []

    def on_epoch_end(self, epoch, logs=None):
        loss, acc = self.model.evaluate(self.test_data, self.test_labels, verbose=0)
        self.test_accuracies.append(acc)
        self.test_losses.append(loss)
        print(f" — Custom Test Acc: {acc:.4f} | Test Loss: {loss:.4f}")

test_inspector = TestPerformanceCallback(X_test, y_test_encoded)

# SMART AI LEARNING RATE: Drops the learning rate by 50% if accuracy gets stuck!
lr_scheduler = tf.keras.callbacks.ReduceLROnPlateau(
    monitor='val_accuracy', factor=0.5, patience=4, min_lr=0.00001, verbose=1
)
# EARLY STOPPING: Saves the absolute best model automatically
early_stopper = tf.keras.callbacks.EarlyStopping(
    monitor='val_accuracy', patience=10, restore_best_weights=True, verbose=1
)

# --- 6. BUILD THE SUPER CNN (VGG-Style) ---
print("\n--- Compiling Super CNN Model ---")
model = tf.keras.Sequential([
    # BLOCK 1: Double Convolution
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same', input_shape=(MAX_TIME_STEPS, N_MFCC, 1)),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.MaxPooling2D((2, 2)), # output: (22, 10)
    tf.keras.layers.Dropout(0.2),

    # BLOCK 2: Double Convolution
    tf.keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.MaxPooling2D((2, 2)), # output: (11, 5)
    tf.keras.layers.Dropout(0.2),

    # BLOCK 3: Smart Pooling
    tf.keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
    tf.keras.layers.BatchNormalization(),
    # CRITICAL FIX: Pool size (2, 1) preserves the MFCC dimension!
    tf.keras.layers.MaxPooling2D((2, 1)), # output: (5, 5) 
    tf.keras.layers.Dropout(0.3),

    # CLASSIFICATION HEAD
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(512, activation='relu'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Dropout(0.4),
    tf.keras.layers.Dense(num_classes, activation='softmax')
])

model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy'])
model.summary()

# --- 7. TRAIN ---
print("\n--- Starting Super CNN Training ---")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    callbacks=[test_inspector, lr_scheduler, early_stopper]
)

# --- 8. PLOT THE CHARTS ---
# Only plot up to the actual stopped epoch (in case Early Stopping triggers)
actual_epochs = len(history.history['accuracy'])
epochs_range = range(1, actual_epochs + 1)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# Plot 1: Accuracy
ax1.plot(epochs_range, history.history['accuracy'], '--', color='red', label='Train Accuracy')
ax1.plot(epochs_range, history.history['val_accuracy'], '-', color='blue', label='Validation Accuracy')
ax1.plot(epochs_range, test_inspector.test_accuracies, ':', color='green', linewidth=2.5, label='Test Accuracy')
ax1.set_title('Super CNN Accuracy Curve')
ax1.set_xlabel('Epoch')
ax1.set_ylabel('Accuracy')
ax1.legend(loc='lower right')
ax1.grid(True, linestyle='--', alpha=0.6)

# Plot 2: Loss
ax2.plot(epochs_range, history.history['loss'], '--', color='red', label='Train Loss')
ax2.plot(epochs_range, history.history['val_loss'], '-', color='blue', label='Validation Loss')
ax2.plot(epochs_range, test_inspector.test_losses, ':', color='green', linewidth=2.5, label='Test Loss')
ax2.set_title('Super CNN Loss Curve')
ax2.set_xlabel('Epoch')
ax2.set_ylabel('Loss')
ax2.legend(loc='upper right')
ax2.grid(True, linestyle='--', alpha=0.6)

plt.tight_layout()
plt.show()

# --- 9. FINAL REPORT ---
print("\n" + "="*50)
print("     FINAL TEST DATASET EVALUATION REPORT")
print("="*50)

y_pred_probs = model.predict(X_test)
y_pred_encoded = np.argmax(y_pred_probs, axis=1)

y_test_names = label_encoder.inverse_transform(y_test_encoded)
y_pred_names = label_encoder.inverse_transform(y_pred_encoded)

final_acc = accuracy_score(y_test_names, y_pred_names)
precision = precision_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
recall = recall_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
f1 = f1_score(y_test_names, y_pred_names, average='weighted', zero_division=0)

print(f"⭐ Final Accuracy : {final_acc * 100:.2f}%")
print(f"🎯 Precision      : {precision * 100:.2f}%")
print(f"🔍 Recall         : {recall * 100:.2f}%")
print(f"⚖️ F1-Score       : {f1 * 100:.2f}%")
print("-" * 50)

report = classification_report(y_test_names, y_pred_names, digits=4)
print("Detailed Summary (Weighted Average):")
lines = report.split('\n')
print(lines[0])
print(lines[-2]) 
print("="*50)