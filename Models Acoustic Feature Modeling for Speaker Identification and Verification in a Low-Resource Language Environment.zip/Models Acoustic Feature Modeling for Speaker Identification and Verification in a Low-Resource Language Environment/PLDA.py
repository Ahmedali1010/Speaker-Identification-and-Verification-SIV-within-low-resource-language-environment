"""
PLDA-Based Speaker Verification / Identification System
========================================================
Training data : C:\\Users\\kara\\Desktop\\VoiceModel\\DataSetTrain&Vali\\DataSet\\CodeModel\\Dataset_complet_for_fitering 2
Test data     : C:\\Users\\kara\\Desktop\\VoiceModel\\VoicesForTest
Audio format  : .ogg
Speaker IDs   : U001M, U001F, … (folder names are the labels)

Dependencies (install once):
    pip install librosa soundfile numpy pandas scikit-learn matplotlib seaborn tqdm
"""

# ──────────────────────────────────────────────────────────────────────────────
# 0.  Imports
# ──────────────────────────────────────────────────────────────────────────────
import os
import time
import warnings
import logging
from pathlib import Pat
from collections import defaultdict

import numpy as np
import pandas as pd
import librosa
from sklearn.decomposition import PCA
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report,
    ConfusionMatrixDisplay,
)
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
from tqdm import tqdm
import matplotlib
matplotlib.use("Agg")          # headless – no display needed
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(levelname)s │ %(message)s")
log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# 1.  Configuration
# ──────────────────────────────────────────────────────────────────────────────
TRAIN_PATH = Path(
    r"C:\Users\kara\Desktop\VoiceModel\DataSetTrain&Vali\DataSet\CodeModel"
    r"\Dataset_complet_for_fitering 2"
)
TEST_PATH = Path(r"C:\Users\kara\Desktop\VoiceModel\VoicesForTest")

SAMPLE_RATE    = 16_000        # Hz – resample everything to this rate
N_MFCC         = 40           # number of MFCC coefficients
N_MELS         = 80           # mel filterbanks for log-mel features
FRAME_HOP      = 0.010        # 10 ms hop
FRAME_WIN      = 0.025        # 25 ms window
MIN_DURATION   = 0.5          # skip clips shorter than this (seconds)
LDA_N_COMPS    = None         # None → min(n_classes-1, n_features)
PCA_VARIANCE   = 0.99         # keep enough PCs to explain 99% variance
OUTPUT_DIR     = Path("speaker_verification_results")
OUTPUT_DIR.mkdir(exist_ok=True)


# ──────────────────────────────────────────────────────────────────────────────
# 2.  Feature extraction helpers
# ──────────────────────────────────────────────────────────────────────────────
def load_audio(path: Path) -> np.ndarray | None:
    """Load an .ogg file, resample to SAMPLE_RATE, return mono waveform."""
    try:
        y, sr = librosa.load(str(path), sr=SAMPLE_RATE, mono=True)
        if len(y) / SAMPLE_RATE < MIN_DURATION:
            return None
        return y
    except Exception as exc:
        log.warning("Could not load %s: %s", path.name, exc)
        return None


def extract_embedding(y: np.ndarray) -> np.ndarray:
    """
    Extract a fixed-length i-vector-style embedding from a raw waveform.

    Features used (all frame-level, then statistics pooled):
        • MFCCs (N_MFCC coefficients) + Δ + ΔΔ
        • Log-mel spectrogram (N_MELS) – mean only
        • Spectral contrast (6 bands + valley)
        • ZCR, RMS energy, spectral centroid, spectral bandwidth

    Statistical pooling: mean + std over time → single vector.
    """
    hop  = int(FRAME_HOP * SAMPLE_RATE)
    win  = int(FRAME_WIN * SAMPLE_RATE)

    # --- MFCCs + deltas ---
    mfcc  = librosa.feature.mfcc(y=y, sr=SAMPLE_RATE, n_mfcc=N_MFCC,
                                   n_fft=win, hop_length=hop)
    d_mfcc  = librosa.feature.delta(mfcc)
    dd_mfcc = librosa.feature.delta(mfcc, order=2)
    mfcc_all = np.vstack([mfcc, d_mfcc, dd_mfcc])    # (3*N_MFCC, T)

    # --- Log-mel ---
    mel = librosa.power_to_db(
        librosa.feature.melspectrogram(y=y, sr=SAMPLE_RATE, n_mels=N_MELS,
                                        n_fft=win, hop_length=hop))  # (N_MELS, T)

    # --- Spectral contrast ---
    contrast = librosa.feature.spectral_contrast(
        y=y, sr=SAMPLE_RATE, n_fft=win, hop_length=hop)              # (7, T)

    # --- Low-level scalar features ---
    zcr      = librosa.feature.zero_crossing_rate(y, hop_length=hop)     # (1, T)
    rms      = librosa.feature.rms(y=y, hop_length=hop)                  # (1, T)
    centroid = librosa.feature.spectral_centroid(
        y=y, sr=SAMPLE_RATE, n_fft=win, hop_length=hop)                  # (1, T)
    bandwidth = librosa.feature.spectral_bandwidth(
        y=y, sr=SAMPLE_RATE, n_fft=win, hop_length=hop)                  # (1, T)

    # Align frame counts to shortest
    T = min(mfcc_all.shape[1], mel.shape[1], contrast.shape[1],
            zcr.shape[1], rms.shape[1], centroid.shape[1], bandwidth.shape[1])
    mfcc_all  = mfcc_all[:, :T]
    mel       = mel[:, :T]
    contrast  = contrast[:, :T]
    zcr       = zcr[:, :T]
    rms       = rms[:, :T]
    centroid  = centroid[:, :T]
    bandwidth = bandwidth[:, :T]

    all_feats = np.vstack([mfcc_all, mel, contrast, zcr, rms, centroid, bandwidth])
    # Statistical pooling: mean + std → (2 * n_feats,)
    return np.concatenate([all_feats.mean(axis=1), all_feats.std(axis=1)])


# ──────────────────────────────────────────────────────────────────────────────
# 3.  Dataset loading
# ──────────────────────────────────────────────────────────────────────────────
def discover_ogg_files(root: Path) -> list[tuple[Path, str]]:
    """
    Walk *root* recursively and collect (file_path, speaker_id) pairs.
    Speaker ID is taken from the first folder-level that matches U\\d+[MF].
    Falls back to the immediate parent folder name.
    """
    import re
    spk_pattern = re.compile(r"U\d+[MF]", re.IGNORECASE)
    items = []
    for ogg in root.rglob("*.ogg"):
        # try to find speaker ID in path parts
        speaker = None
        for part in ogg.parts:
            if spk_pattern.match(part):
                speaker = part.upper()
                break
        if speaker is None:
            speaker = ogg.parent.name.upper()   # fallback
        items.append((ogg, speaker))
    return items


def build_dataset(root: Path, desc: str = "Loading") -> tuple[np.ndarray, np.ndarray]:
    """Return (embeddings, labels) arrays for all .ogg files under root."""
    files = discover_ogg_files(root)
    if not files:
        raise FileNotFoundError(f"No .ogg files found under {root}")

    embeddings, labels = [], []
    for path, spk in tqdm(files, desc=desc, unit="file"):
        y = load_audio(path)
        if y is None:
            continue
        emb = extract_embedding(y)
        embeddings.append(emb)
        labels.append(spk)

    X = np.array(embeddings, dtype=np.float32)
    y = np.array(labels)
    log.info("%s: %d utterances from %d speakers", desc, len(y), len(set(y)))
    return X, y


# ──────────────────────────────────────────────────────────────────────────────
# 4.  PLDA-style pipeline
# ──────────────────────────────────────────────────────────────────────────────
# Scikit-learn does not ship a native PLDA estimator, but the standard approach
# for speaker recognition is:
#   1. PCA  – whiten / reduce dimensionality
#   2. LDA  – class-discriminant projection (equivalent to the "between-class"
#              component of PLDA)
#   3. Nearest-centroid or softmax scoring for identification
#
# This is often called "PLDA-lite" or "LDA i-vector system" in the literature
# and gives results close to full PLDA on small datasets.
# ──────────────────────────────────────────────────────────────────────────────

def build_plda_pipeline(n_classes: int) -> Pipeline:
    n_lda = min(n_classes - 1, 200) if LDA_N_COMPS is None else LDA_N_COMPS
    return Pipeline([
        ("scaler", StandardScaler()),
        ("pca",    PCA(n_components=PCA_VARIANCE, whiten=True, random_state=42)),
        ("lda",    LinearDiscriminantAnalysis(n_components=n_lda,
                                               solver="svd", store_covariance=True)),
    ])


# ──────────────────────────────────────────────────────────────────────────────
# 5.  Identification head (nearest centroid in LDA space)
# ──────────────────────────────────────────────────────────────────────────────
class NearestCentroidClassifier:
    """Cosine-distance nearest centroid after PLDA projection."""

    def __init__(self, metric: str = "cosine"):
        self.metric = metric
        self.centroids_: np.ndarray | None = None
        self.classes_: np.ndarray | None = None

    def fit(self, X: np.ndarray, y: np.ndarray) -> "NearestCentroidClassifier":
        classes = np.unique(y)
        self.classes_ = classes
        self.centroids_ = np.vstack([X[y == c].mean(axis=0) for c in classes])
        return self

    def _cosine_distances(self, X: np.ndarray) -> np.ndarray:
        # X: (N, D), centroids: (C, D) → distances: (N, C)
        X_norm = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
        C_norm = self.centroids_ / (
            np.linalg.norm(self.centroids_, axis=1, keepdims=True) + 1e-12)
        return 1.0 - X_norm @ C_norm.T   # lower = more similar

    def predict(self, X: np.ndarray) -> np.ndarray:
        dist = self._cosine_distances(X)
        return self.classes_[np.argmin(dist, axis=1)]

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        dist = self._cosine_distances(X)
        # Convert distance to similarity score, then softmax
        sim = 1.0 - dist
        exp = np.exp(sim - sim.max(axis=1, keepdims=True))
        return exp / exp.sum(axis=1, keepdims=True)


# ──────────────────────────────────────────────────────────────────────────────
# 6.  Training & evaluation
# ──────────────────────────────────────────────────────────────────────────────
def train_and_evaluate():
    log.info("=" * 70)
    log.info("  PLDA Speaker Verification / Identification System")
    log.info("=" * 70)

    # --- Load data ---
    log.info("\n[1/5] Loading training data …")
    t0 = time.time()
    X_train, y_train_raw = build_dataset(TRAIN_PATH, "Train")
    log.info("  Feature dim : %d", X_train.shape[1])
    log.info("  Load time   : %.1f s", time.time() - t0)

    log.info("\n[2/5] Loading test data …")
    X_test, y_test_raw = build_dataset(TEST_PATH, "Test")

    # Encode labels
    le = LabelEncoder()
    le.fit(np.concatenate([y_train_raw, y_test_raw]))
    y_train = le.transform(y_train_raw)
    y_test  = le.transform(y_test_raw)
    n_classes = len(le.classes_)
    log.info("  Total speakers : %d", n_classes)

    # --- Build & train PLDA pipeline ---
    log.info("\n[3/5] Training PLDA pipeline …")
    t0 = time.time()
    pipeline = build_plda_pipeline(n_classes)
    pipeline.fit(X_train, y_train)
    train_time = time.time() - t0
    log.info("  Training time : %.2f s", train_time)

    # PCA info
    pca_step = pipeline.named_steps["pca"]
    lda_step = pipeline.named_steps["lda"]
    log.info("  PCA kept      : %d / %d dims (%.1f%% var)",
             pca_step.n_components_, X_train.shape[1],
             pca_step.explained_variance_ratio_.sum() * 100)
    log.info("  LDA output    : %d dims", lda_step.scalings_.shape[1])

    # Project data
    X_train_lda = pipeline.transform(X_train)
    X_test_lda  = pipeline.transform(X_test)

    # --- Nearest-centroid classifier ---
    clf = NearestCentroidClassifier()
    clf.fit(X_train_lda, y_train)

    # --- Evaluate on training set ---
    y_train_pred = clf.predict(X_train_lda)
    train_acc = accuracy_score(y_train, y_train_pred)

    # --- Evaluate on test set ---
    log.info("\n[4/5] Evaluating on test data …")
    y_pred = clf.predict(X_test_lda)

    acc   = accuracy_score(y_test, y_pred)
    prec  = precision_score(y_test, y_pred, average="macro", zero_division=0)
    rec   = recall_score(y_test, y_pred,    average="macro", zero_division=0)
    f1    = f1_score(y_test, y_pred,        average="macro", zero_division=0)
    cm    = confusion_matrix(y_test, y_pred)

    # Speaker-level breakdown
    report_str = classification_report(
        y_test, y_pred,
        labels=np.arange(n_classes),
        target_names=le.classes_,
        zero_division=0,
    )

    # Cross-validation on training set (5-fold) — mimics "learning curve"
    log.info("\n[5/5] 5-fold cross-validation on training set …")
    from sklearn.pipeline import Pipeline as SKPipeline
    from sklearn.neighbors import NearestCentroid

    cv_pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("pca",    PCA(n_components=min(50, X_train.shape[1] - 1),
                       whiten=True, random_state=42)),
        ("lda",    LinearDiscriminantAnalysis(solver="svd")),
        ("nc",     NearestCentroid()),
    ])
    cv_scores = cross_val_score(cv_pipeline, X_train, y_train,
                                 cv=5, scoring="accuracy", n_jobs=-1)
    cv_mean, cv_std = cv_scores.mean(), cv_scores.std()

    # ──────────────────────────────────────────────────────────────────────
    # 7.  Print results
    # ──────────────────────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  EVALUATION RESULTS")
    print("=" * 70)
    print(f"  Total speakers          : {n_classes}")
    print(f"  Training utterances     : {len(y_train)}")
    print(f"  Test utterances         : {len(y_test)}")
    print(f"  Training time           : {train_time:.2f} s")
    print("-" * 70)
    print(f"  Train accuracy          : {train_acc*100:.2f}%")
    print(f"  Test  accuracy          : {acc*100:.2f}%")
    print(f"  Test  precision (macro) : {prec*100:.2f}%")
    print(f"  Test  recall    (macro) : {rec*100:.2f}%")
    print(f"  Test  F1-score  (macro) : {f1*100:.2f}%")
    print("-" * 70)
    print(f"  CV accuracy (5-fold)    : {cv_mean*100:.2f}% ± {cv_std*100:.2f}%")
    print(f"  CV scores               : {[f'{s*100:.1f}%' for s in cv_scores]}")
    print("-" * 70)
    print(f"\n  PCA components          : {pca_step.n_components_}")
    print(f"  LDA components          : {lda_step.scalings_.shape[1]}")
    print(f"  Embedding dim (raw)     : {X_train.shape[1]}")
    print("\n  ── Per-Speaker Report ──")
    print(report_str)

    # ──────────────────────────────────────────────────────────────────────
    # 8.  Save metrics to CSV
    # ──────────────────────────────────────────────────────────────────────
    metrics_df = pd.DataFrame({
        "Metric": ["Train Accuracy", "Test Accuracy", "Precision (macro)",
                   "Recall (macro)", "F1-Score (macro)",
                   "CV Mean Accuracy", "CV Std Accuracy",
                   "Training Time (s)", "Speakers", "Train Utterances",
                   "Test Utterances", "PCA Dims", "LDA Dims"],
        "Value": [
            f"{train_acc:.4f}", f"{acc:.4f}", f"{prec:.4f}",
            f"{rec:.4f}", f"{f1:.4f}",
            f"{cv_mean:.4f}", f"{cv_std:.4f}",
            f"{train_time:.2f}", n_classes, len(y_train),
            len(y_test), pca_step.n_components_, lda_step.scalings_.shape[1],
        ],
    })
    metrics_path = OUTPUT_DIR / "metrics_summary.csv"
    metrics_df.to_csv(metrics_path, index=False)
    log.info("Metrics saved → %s", metrics_path)

    # ──────────────────────────────────────────────────────────────────────
    # 9.  Confusion matrix plot
    # ──────────────────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(max(8, n_classes), max(6, n_classes)))
    sns.heatmap(cm, annot=(n_classes <= 20), fmt="d", cmap="Blues",
                xticklabels=le.classes_, yticklabels=le.classes_, ax=ax,
                linewidths=0.3 if n_classes <= 20 else 0)
    ax.set_xlabel("Predicted Speaker")
    ax.set_ylabel("True Speaker")
    ax.set_title("Confusion Matrix – PLDA Speaker Identification")
    plt.xticks(rotation=45, ha="right", fontsize=max(6, 10 - n_classes // 10))
    plt.yticks(rotation=0,  fontsize=max(6, 10 - n_classes // 10))
    plt.tight_layout()
    cm_path = OUTPUT_DIR / "confusion_matrix.png"
    fig.savefig(cm_path, dpi=150)
    plt.close(fig)
    log.info("Confusion matrix saved → %s", cm_path)

    # ──────────────────────────────────────────────────────────────────────
    # 10.  CV learning-curve bar chart
    # ──────────────────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(8, 4))
    folds = [f"Fold {i+1}" for i in range(len(cv_scores))]
    bars  = ax.bar(folds, cv_scores * 100, color="#4C72B0", edgecolor="white")
    ax.axhline(cv_mean * 100, color="red", linestyle="--",
               label=f"Mean = {cv_mean*100:.1f}%")
    ax.set_ylim(0, 110)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("5-Fold Cross-Validation Accuracy (Training Set)")
    ax.legend()
    for bar, val in zip(bars, cv_scores):
        ax.text(bar.get_x() + bar.get_width() / 2, val * 100 + 1,
                f"{val*100:.1f}%", ha="center", va="bottom", fontsize=9)
    plt.tight_layout()
    cv_path = OUTPUT_DIR / "cv_learning_curve.png"
    fig.savefig(cv_path, dpi=150)
    plt.close(fig)
    log.info("CV chart saved → %s", cv_path)

    # ──────────────────────────────────────────────────────────────────────
    # 11.  LDA embedding scatter (first 2 components, test set)
    # ──────────────────────────────────────────────────────────────────────
    if X_test_lda.shape[1] >= 2:
        fig, ax = plt.subplots(figsize=(10, 7))
        unique_spks = np.unique(y_test)
        cmap = plt.cm.get_cmap("tab20", len(unique_spks))
        for idx, spk in enumerate(unique_spks):
            mask = y_test == spk
            ax.scatter(X_test_lda[mask, 0], X_test_lda[mask, 1],
                       c=[cmap(idx)], label=le.classes_[spk],
                       s=40, alpha=0.7, edgecolors="none")
        ax.set_xlabel("LDA Component 1")
        ax.set_ylabel("LDA Component 2")
        ax.set_title("PLDA Embedding Space – Test Set (first 2 LDA dims)")
        if n_classes <= 30:
            ax.legend(fontsize=7, ncol=2, loc="best")
        plt.tight_layout()
        emb_path = OUTPUT_DIR / "lda_embedding_scatter.png"
        fig.savefig(emb_path, dpi=150)
        plt.close(fig)
        log.info("Embedding scatter saved → %s", emb_path)

    log.info("\nAll outputs written to: %s", OUTPUT_DIR.resolve())
    print("\nDone ✓  Results in:", OUTPUT_DIR.resolve())


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Quick sanity check on paths before doing any heavy lifting
    for label, path in [("TRAIN", TRAIN_PATH), ("TEST", TEST_PATH)]:
        if not path.exists():
            raise SystemExit(
                f"[ERROR] {label} path not found:\n  {path}\n"
                "Please update the TRAIN_PATH / TEST_PATH variables at the top of this script."
            )
    train_and_evaluate()