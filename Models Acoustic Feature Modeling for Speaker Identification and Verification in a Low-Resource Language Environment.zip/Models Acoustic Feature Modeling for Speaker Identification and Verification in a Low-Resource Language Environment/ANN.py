import os
import zipfile
import numpy as np
import librosa
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
from tqdm import tqdm
import tensorflow as tf

# --- 1. CONFIGURATION PATHS ---
TRAIN_VAL_BASE_DIR = r'/content/extracted_train_val'
TEST_BASE_DIR = r'/content/extracted_test'

# --- 2. AUTOMATIC UNZIPPER & FOLDER FINDER ---
def extract_and_find_data(zip_path, extract_dir):
    if not os.path.exists(zip_path):
        raise FileNotFoundError(f"❌ ERROR: Cannot find '{zip_path}'. Please upload it!")
        
    os.makedirs(extract_dir, exist_ok=True)
    print(f"📦 Extracting {zip_path}...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
        
    current_dir = extract_dir
    while True:
        contents = [f for f in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, f))]
        if len(contents) == 1:
            current_dir = os.path.join(current_dir, contents[0])
        else:
            break
    return current_dir

TRAIN_VAL_DIR = extract_and_find_data(TRAIN_VAL_ZIP, TRAIN_VAL_BASE_DIR)
TEST_DIR = extract_and_find_data(TEST_ZIP, TEST_BASE_DIR)

# --- 3. MODEL SETTINGS ---
SAMPLE_RATE = 22050
N_MFCC = 20
EPOCHS = 20
BATCH_SIZE = 32

# --- 4. ANN FEATURE EXTRACTION FUNCTION ---
def extract_features(file_path):
    """Extracts MFCCs and averages them into a 1D array for the ANN."""
    try:
        audio, sr = librosa.load(file_path, sr=SAMPLE_RATE, duration=1.0)
        if len(audio) < 2048: 
            return None
            
        mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
        # Take the mean across the time axis to create a single 20-feature vector
        mfcc_mean = np.mean(mfcc.T, axis=0) 
        return mfcc_mean
    except Exception:
        return None

# --- 5. SMART DATA COLLECTION ---
def load_data_from_directory(directory):
    dataset = []
    print(f"🔍 Scanning directory: {directory}")
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.wav', '.mp3', '.ogg')):
                dataset.append({
                    'speaker': os.path.basename(root),
                    'path': os.path.join(root, file)
                })
    return dataset

def prepare_xy(dataset):
    X, y = [], []
    for item in tqdm(dataset, desc="Processing Audio"):
        features = extract_features(item['path'])
        if features is not None:
            X.append(features)
            y.append(item['speaker'])
    return np.array(X), np.array(y)

print("\n--- Loading Data ---")
train_val_raw = load_data_from_directory(TRAIN_VAL_DIR)
test_raw = load_data_from_directory(TEST_DIR)

print("\n--- Extracting Features for Training & Validation ---")
X_train_val, y_train_val = prepare_xy(train_val_raw)

print("\n--- Extracting Features for Testing ---")
X_test, y_test = prepare_xy(test_raw)

# Encode Speaker Names (Strings) into Numbers (0, 1, 2...) for the Neural Network
label_encoder = LabelEncoder()
# Fit on all possible labels to ensure consistency
label_encoder.fit(np.concatenate((y_train_val, y_test))) 

y_train_val_encoded = label_encoder.transform(y_train_val)
y_test_encoded = label_encoder.transform(y_test)
num_classes = len(label_encoder.classes_)

# Split Training and Validation
X_train, X_val, y_train, y_val = train_test_split(
    X_train_val, y_train_val_encoded, test_size=0.15, random_state=42
)

print(f"\n📊 Data Split Summary:")
print(f"Total Classes (Speakers): {num_classes}")
print(f"Training Files:   {len(X_train)}")
print(f"Validation Files: {len(X_val)}")
print(f"Testing Files:    {len(X_test)}")

# --- 6. BUILD THE ARTIFICIAL NEURAL NETWORK (ANN) ---
print("\n--- Compiling ANN Model ---")
model = tf.keras.Sequential([
    # Input Layer & First Hidden Layer
    tf.keras.layers.Dense(256, activation='relu', input_shape=(N_MFCC,)),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Dropout(0.3),
    
    # Second Hidden Layer
    tf.keras.layers.Dense(128, activation='relu'),
    tf.keras.layers.BatchNormalization(),
    tf.keras.layers.Dropout(0.3),
    
    # Output Layer (One node per speaker, Softmax for probabilities)
    tf.keras.layers.Dense(num_classes, activation='softmax')
])

model.compile(optimizer='adam', 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy'])

model.summary()

# --- 7. TRAIN THE ANN ---
print("\n--- Starting Neural Network Training ---")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE
)

# --- 8. PLOT THE CHART ---
print("\nGenerating Learning Curve...")
plt.figure(figsize=(10, 6))

iterations_range = range(1, EPOCHS + 1)
plt.plot(iterations_range, history.history['accuracy'], marker='s', color='blue', label='train')
plt.plot(iterations_range, history.history['val_accuracy'], marker='*', color='lawngreen', label='validation')

plt.title('ANN Iterative Performance')
plt.xlabel('Epochs (Iterations)')
plt.ylabel('Accuracy')
plt.legend(loc='lower right')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# --- 9. FINAL METRICS & REPORT ---
print("\n" + "="*50)
print("     FINAL TEST DATASET EVALUATION REPORT")
print("="*50)

# Predict on the unseen test data
y_pred_probs = model.predict(X_test)
y_pred_encoded = np.argmax(y_pred_probs, axis=1)

# Decode numbers back to speaker names for the report
y_test_names = label_encoder.inverse_transform(y_test_encoded)
y_pred_names = label_encoder.inverse_transform(y_pred_encoded)

final_acc = accuracy_score(y_test_names, y_pred_names)
precision = precision_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
recall = recall_score(y_test_names, y_pred_names, average='weighted', zero_division=0)
f1 = f1_score(y_test_names, y_pred_names, average='weighted', zero_division=0)

print(f"⭐ Final Accuracy : {final_acc * 100:.2f}%")
print(f"🎯 Precision      : {precision * 100:.2f}%")
print(f"🔍 Recall         : {recall * 100:.2f}%")
print(f"⚖️ F1-Score       : {f1 * 100:.2f}%")
print("-" * 50)

report = classification_report(y_test_names, y_pred_names, digits=4)
print("Detailed Summary (Weighted Average):")
lines = report.split('\n')
print(lines[0])
print(lines[-2]) 
print("="*50)